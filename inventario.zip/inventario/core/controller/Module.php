<?php


// 13 de Abril del 2014
// Module.php
// @brief tareas que se realizan con modulos.

class Module {

	public static function loadLayout(){
		include "core/app/layouts/layout.php";
	}


}



?>
